﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace palindrol_szamok
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private List<int> FindPalindroms(int n)
        {
            List<int> palindroms = new List<int>();
            for (int i = 0; i < n; i++)
            {
                if (IsPalindrom(i))
                {
                    palindroms.Add(i);
                }
            }
            return palindroms;
        }

        private bool IsPalindrom(int number)
        {
            string numStr = number.ToString();
            int left = 0;
            int right = numStr.Length - 1;
            while (left < right)
            {
                if (numStr[left] != numStr[right])
                {
                    return false;
                }
                left++;
                right--;
            }
            return true;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(txtN.Text, out int n) && n > 0)
            {
                List<int> palindroms = FindPalindroms(n);
                PalindromsLista.Items.Clear();
                foreach (int palindrom in palindroms)
                {
                    PalindromsLista.Items.Add(palindrom);
                }
            }
            else
            {
                MessageBox.Show("Hibás bemenet. Kérjük, adjon meg egy pozitív egész számot (N)!");
            }
        }
    }
}
